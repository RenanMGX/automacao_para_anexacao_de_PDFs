

if __name__ == "__main__":
    # Import for DesktopBot
    from botcity.core import DesktopBot, Backend, Application
    
    # Instantiating DesktopBot
    bot = DesktopBot()
    
    # Application path
    app_path = r"C:\Program Files (x86)\SAP\FrontEnd\SAPgui\saplogon.exe"
    
    # Launching the app
    bot.execute(app_path)
    
    # Connecting to the application using 'path' selector
    # Adjust the 'Backend' type according to your application
    current_app = bot.connect_to_app(backend=Backend.UIA, path=app_path)
    
    # Getting the main window reference
    main_window = current_app.top_window() if isinstance(current_app, Application) else current_app
    main_window.set_focus()
    
    parent_1 = bot.find_app_element(waiting_time=10000, from_parent_window=main_window, best_match="Documentos", control_type="TreeItem")
    target_element = bot.find_app_element(waiting_time=10000, from_parent_window=parent_1, best_match="SAP", control_type="TreeItem")
    
    parent_1 = bot.find_app_element(waiting_time=10000, from_parent_window=main_window, best_match="Documentos")
    target_element = bot.find_app_element(waiting_time=10000, from_parent_window=parent_1, best_match="SAP")
    
        
    
    
    
    